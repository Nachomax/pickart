"use strict";
var testing_1 = require("@angular/core/testing");
var contenido_component_1 = require("./contenido.component");
describe('ContenidoComponent', function () {
    var component;
    var fixture;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [contenido_component_1.ContenidoComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(contenido_component_1.ContenidoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=contenido.component.spec.js.map