"use strict";
var testing_1 = require("@angular/core/testing");
var visorimg_component_1 = require("./visorimg.component");
describe('VisorimgComponent', function () {
    var component;
    var fixture;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [visorimg_component_1.VisorimgComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(visorimg_component_1.VisorimgComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=visorimg.component.spec.js.map