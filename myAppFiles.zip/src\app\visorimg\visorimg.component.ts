import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visorimg',
  templateUrl: './visorimg.component.html',
  styleUrls: ['./visorimg.component.css']
})
export class VisorimgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
